# Handoff: Redesign UI/UX — Sistema TOV (Centro TOV de Formação Teológica)

## Overview
Redesign visual completo do sistema acadêmico **kafune/sistemaSeminario** aplicando o
design system **TOV** (coral/slate). Cobre as 10 telas: Login, Dashboard (nova),
Alunos (lista), Ficha do aluno, Turmas, Turma detalhe, Notas e faltas (lançamento em
grade), Relatórios, Professores e Matérias.

## Sobre os arquivos deste pacote
`Sistema TOV.dc.html` é uma **referência de design em HTML** — um catálogo de telas de
alta fidelidade mostrando aparência e comportamento pretendidos. **Não é código de
produção pra copiar direto.** A tarefa é **recriar essas telas no frontend já existente**
(React 18 + Vite + MUI 5, em `frontend/src/`), reaproveitando os componentes MUI, o
`api.js` e o roteamento que já estão no repo. Nenhuma regra de negócio muda — só a camada
visual e alguns fluxos de UX apontados abaixo.

## Fidelidade
**Alta fidelidade (hifi).** Cores, tipografia, espaçamentos e raios estão finais. Recriar
pixel-perfect usando MUI + `sx`/`ThemeProvider`. Onde o HTML usa "caixas fake" (inputs,
toggles), trocar pelos componentes MUI reais equivalentes (`TextField`, `Switch`, etc.).

## Como aplicar no repo (visão geral)
1. **Tema global** — substituir o tema verde em `frontend/src/main.jsx` pelo tema coral
   (ver `theme.tov.js` neste pacote): `primary.main = #F14949`, `secondary.main = #4A575E`,
   fundo `#F7F4F1`, fontes Bricolage Grotesque (títulos) + Open Sans (corpo). Importar as
   fontes no `frontend/index.html` (links do Google Fonts em `tokens.css`).
2. **Layout/Sidebar** — reescrever `frontend/src/Layout.jsx`: hoje é `AppBar` + `Drawer`
   MUI. Trocar por uma **sidebar coral fixa (262px)** com wordmark "TOV", label de seção,
   itens de nav com estado ativo em pílula branca (texto coral), e card de usuário +
   "Sair" no rodapé. Adicionar item **Dashboard** no topo do `MENU`.
3. **Reskin tela a tela** — seguir o mapeamento abaixo. Manter `Paper`/`Table`/`Dialog`
   mas estilizar via `sx` com os tokens.

## Mapeamento telas → arquivos do repo
| # | Tela (no HTML) | Arquivo no repo | Ação |
|---|---|---|---|
| 01 | Login | `frontend/src/pages/Login.jsx` | Split-screen coral (painel esquerdo coral com versículo, form à direita). Trocar `bgcolor:'#eef2e0'` e cores. |
| 02 | Dashboard | **novo** `frontend/src/pages/Dashboard.jsx` | Criar rota `/` → Dashboard (hoje `/` cai em Alunos). 4 cards de métrica, "Matrículas por curso", "Atividade recente". Dados: novos endpoints de agregação ou derivar do existente. |
| 03 | Alunos | `frontend/src/pages/Alunos.jsx` | Tabela virou card `border-radius:16`; header com régua + busca + "Novo aluno"; chips de filtro; status como pílulas; paginação em pílulas. |
| 04 | Ficha do aluno | `frontend/src/pages/AlunoDetalhe.jsx` | Header com avatar (iniciais), nome grande, chips matrícula/status; grid de dados 3 col; coluna direita com cards de resumo (média, faltas, situação); tabela de notas. |
| 05 | Turmas | `frontend/src/pages/Turmas.jsx` | Trocar tabela por **grid de cards** (3 col) + card "criar" tracejado. |
| 06 | Turma detalhe | `frontend/src/pages/TurmaDetalhe.jsx` | Manter `Tabs` (Alunos / Matérias); reestilizar header e tabelas. |
| 07 | Notas e faltas | `frontend/src/pages/Notas.jsx` | **Mudança de UX:** de "um aluno por vez" para **lançamento em grade por turma+matéria** — seletores Turma/Matéria/Período + grade editável (nota/faltas inline, toggle "Cursou") e "Salvar grade" em lote. Ver "Interações". |
| 08 | Relatórios | `frontend/src/pages/Relatorios.jsx` | 2 cards (por aluno / por turma) + faixa escura de geração em lote com dropzone. Botões chamam os mesmos endpoints `/relatorios/*`. |
| 09 | Professores | `frontend/src/pages/Professores.jsx` | Reskin da tabela + status em pílula. |
| 10 | Matérias | `frontend/src/pages/Materias.jsx` | Reskin da tabela + área como chip. |

## Interações & comportamento (o que preservar / mudar)
- **Navegação:** rotas em `App.jsx` inalteradas, exceto adicionar `/` → `Dashboard` e
  manter `/alunos` etc. Itens da sidebar navegam via `react-router`.
- **Alunos:** busca (`GET /alunos?busca=&pagina=&por_pagina=25`), paginação, "Novo aluno"
  abre `AlunoForm` (Dialog existente). Ações por linha: ver ficha (`/alunos/:codAlu`) e
  boletim PDF (`abrirArquivo('/relatorios/boletim/:codAlu')`).
- **Notas (novo fluxo em grade):** selecionar turma → carregar alunos da turma
  (`GET /turmas/:codTur/alunos`) + matéria/professor; render de uma linha por aluno com
  inputs de nota (0–10, step .1) e faltas; toggle "Cursou" (S/N). "Salvar grade" faz
  `POST`/`PUT` em `/notas/aluno/:codAlu` por linha alterada (marcar linhas sujas em coral).
  Manter também acesso ao diário PDF (`/relatorios/diario/:codTur?cod_mat=`). O fluxo
  antigo por aluno pode virar uma aba secundária, se desejado.
- **Relatórios:** mesmos endpoints — `/relatorios/{boletim,historico,ficha-aluno}/:codAlu`,
  `/relatorios/{lista-turma,diario,boletim-turma}/:codTur`, e lote via
  `POST /relatorios/lote?tipo=boletim|historico` (FormData, baixa ZIP). Ver `api.js`
  (`abrirArquivo`, `enviarArquivoEBaixar`).
- **Estados:** loading (skeletons nos cards/linhas), vazio (ex.: "Digite ao menos 2 letras"
  nos autocompletes), erro (Snackbar coral). Hover de linha: fundo `#F7F4F1`.

## Design tokens (resumo — completo em `tokens.css` / `theme.tov.js`)
**Cores:** Coral `#F14949` · Coral hover `#D93B3B` · Slate `#4A575E` · Off-white `#F7F4F1`
· Branco `#FFFFFF` · Tinta (texto) `#16181A` · Cinza legenda `#8A949A` · Borda input `#E2DBD5`.
**Tipografia:** Títulos **Bricolage Grotesque** 600/700, `line-height:1.02`,
`letter-spacing:-.01em`. Corpo **Open Sans** 400–700, `line-height:1.5`. Eyebrow: Bricolage
600, `letter-spacing:.2em`, uppercase, `#8A949A`.
**Elementos:** Régua 64×5px coral `border-radius:3px` (marcador de seção). Card
`border-radius:16px`, padding `26–28px 30px`. Card compacto `border-radius:12px`, padding
`16px 20px`. Pílula/status `border-radius:999px`, padding `5px 12px`. Grid `gap:12–22px`.
Sombra de card sutil; sombra de botão coral `0 12px 24px -10px rgba(241,73,73,.7)`.
Sidebar: largura 262px, fundo coral, item ativo = fundo branco + texto coral, raio 11px.

## Assets
Sem imagens externas. Avatares = iniciais em caixa coral. Ícones: o repo já usa
`@mui/icons-material` — manter os equivalentes (School, Person, MenuBook, Groups,
EditNote, Description, Logout) e adicionar um de Dashboard (ex.: `SpaceDashboard`). Marcadores
de nav no HTML são quadradinhos decorativos; troque pelos ícones MUI.

## Arquivos neste pacote
- `Sistema TOV.dc.html` — catálogo das 10 telas (abrir no navegador).
- `tokens.css` — variáveis CSS + imports de fonte.
- `theme.tov.js` — `createTheme` MUI pronto pra colar em `main.jsx`.
