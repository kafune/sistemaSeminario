// Tema MUI do design system TOV — substitui o tema verde em frontend/src/main.jsx.
// Uso:
//   import { createTheme, ThemeProvider, CssBaseline } from '@mui/material'
//   import { ptBR } from '@mui/material/locale'
//   import { tovTheme } from './theme.tov'
//   <ThemeProvider theme={tovTheme}> ... </ThemeProvider>
import { createTheme } from '@mui/material'
import { ptBR } from '@mui/material/locale'

const coral = '#F14949'
const coralHover = '#D93B3B'
const slate = '#4A575E'

export const tovTheme = createTheme(
  {
    palette: {
      primary:   { main: coral, dark: coralHover, contrastText: '#fff' },
      secondary: { main: slate },
      background: { default: '#F7F4F1', paper: '#FFFFFF' },
      text:      { primary: '#16181A', secondary: '#8A949A' },
      divider:   '#EDE6E0',
    },
    typography: {
      fontFamily: "'Open Sans', sans-serif",
      h1: { fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 700, lineHeight: 1.02, letterSpacing: '-.01em' },
      h2: { fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 700, lineHeight: 1.02, letterSpacing: '-.01em' },
      h3: { fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 700, lineHeight: 1.05 },
      h5: { fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 700 },
      h6: { fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 700 },
      button: { textTransform: 'none', fontWeight: 700 },
      overline: { fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 600, letterSpacing: '.2em' },
    },
    shape: { borderRadius: 12 },
    components: {
      MuiPaper:  { styleOverrides: { rounded: { borderRadius: 16 } } },
      MuiButton: {
        styleOverrides: {
          root: { borderRadius: 11, paddingInline: 18, height: 46 },
          containedPrimary: { boxShadow: '0 12px 24px -10px rgba(241,73,73,.7)' },
        },
      },
      MuiChip:   { styleOverrides: { root: { borderRadius: 999, fontWeight: 700 } } },
      MuiOutlinedInput: { styleOverrides: { root: { borderRadius: 11 } } },
      MuiTableCell: { styleOverrides: { head: { fontFamily: "'Bricolage Grotesque', sans-serif", fontWeight: 600, letterSpacing: '.12em', textTransform: 'uppercase', color: '#8A949A', fontSize: 11 } } },
    },
  },
  ptBR,
)
